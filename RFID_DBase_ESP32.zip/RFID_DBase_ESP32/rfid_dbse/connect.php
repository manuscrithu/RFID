<?php
// Database configuration
$servername = "localhost"; 
$username = "bhanuka";
$password = "mysql";
$dbname = "esp32";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$borrowed_item1 = null;
$borrowed_item2 = null;
$stmt = null;

if(isset($_POST["borrowed_item1"])) {
    $borrowed_item1 = $_POST["borrowed_item1"];

    if($borrowed_item1 == "false") {
        $stmt = "update stocks set stockamount = stockamount - 1 where itemid = '1234'";
    }
    else {
        $stmt = "update stocks set stockamount = stockamount + 1 where itemid = '1234'";
    }
}

if(isset($_POST["borrowed_item2"])) {
    $borrowed_item2 = $_POST["borrowed_item2"];

    if($borrowed_item2 == "false") {
        $stmt = "update stocks set stockamount = stockamount - 1 where itemid = '4567'";
    }
    else {
        $stmt = "update stocks set stockamount = stockamount + 1 where itemid = '4567'";
    }
}

if ($conn->query($stmt)) {
    echo "Updated successfully";
} else {
    echo "Error";
}

$conn->close();
?>